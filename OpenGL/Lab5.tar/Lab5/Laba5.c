#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>

const float Width = 1024, Height = 600;
float Visio = 60.0;
float zPos =  -50.0;
float Sx= 1.0;
float Sy= 1.0;
float Sz= 1.0;
float RotY = 0.0, RotX = 0.0;
float RotDiff = 3.0;
float hgap = 2.00;
const float norm = 1.1;
const float Scal= 1.025;
int gradient = 0;
int normal = 0;
int qnormal = 0;
int light = 0;
int texture = 0;

GLuint LoadTexture( const char * filename )
{

  GLuint texture;

  int width, height;

  unsigned char * data;

  FILE * file;

  file = fopen( filename, "rb" );

  if ( file == NULL ) return 0;
  width = 512;
  height = 256;
  data = (unsigned char *)malloc( width * height * 3 );
  //int size = fseek(file,);
  fread( data, width * height * 3, 1, file );
  fclose( file );

 int i;
 for(i = 0; i < width * height ; ++i)
{
   int index = i*3;
   unsigned char B,R;
   B = data[index];
   R = data[index+2];

   data[index] = R;
   data[index+2] = B;

}


glGenTextures( 1, &texture );
glBindTexture( GL_TEXTURE_2D, texture );
glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE,GL_MODULATE );
glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST );


glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER,GL_LINEAR );
glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,GL_REPEAT );
glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,GL_REPEAT );
gluBuild2DMipmaps( GL_TEXTURE_2D, 3, width, height,GL_RGB, GL_UNSIGNED_BYTE, data );
free( data );

return texture;
}

void DrawQuad(float x1, float x2, float x3, float x4, float y1, float y2, float y3, float y4, float z1, float z2, float z3, float z4) {
   if(gradient == 1) {
     glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
     glShadeModel(GL_FLAT);
     //glShadeModel(GL_SMOOTH);
 }
   else{
	 glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);  
     glShadeModel(GL_FLAT);
 }	 
 
   glColor3f(1.0, 1.0, 0.0);
   //Рисуем полигон
   glBegin(GL_QUADS);
   
    //glColor3f(1.0, 0.0, 0.0);

    if(texture) glTexCoord3f(x1*norm, y1*norm, z1*norm);
    glNormal3f(x1*norm, y1*norm, z1*norm);
    glVertex3f(x1, y1, z1);
        
    //glColor3f(0.0, 0.0, 1.0);
    if(texture) glTexCoord3f(x2*norm, y2*norm, y2*norm);
    glNormal3f(x2*norm, y2*norm, y2*norm);
    glVertex3f(x2, y2, z2);
        
    //glColor3f(1.0, 1.0, 0.0);
    if(texture) glTexCoord3f(x3*norm, y3*norm, z3*norm);
    glNormal3f(x3*norm, y3*norm, z3*norm);
    glVertex3f(x3, y3, z3);
        
    //glColor3f(0.0, 1.0, 0.0);
    if(texture) glTexCoord3f(x4*norm, y4*norm, z4*norm);
    glNormal3f(x4*norm, y4*norm, z4*norm);
    glVertex3f(x4, y4, z4);
   glEnd();
   
if(normal) { 
  //Рисуем по Четыре нормали
    glBegin(GL_LINES);
	 glColor3f(1.0, 0.0, 0.0);
	 glVertex3f(x1, y1, z1);
	 glVertex3f(x1*norm, y1*norm, z1*norm);
   glEnd();
   
   glBegin(GL_LINES);
	 glColor3f(0.0, 0.0, 1.0);
	 glVertex3f(x2, y2, z2);
	 glVertex3f(x2*norm, y2*norm, z2*norm);
   glEnd();
   
   glBegin(GL_LINES);
	 glColor3f(0.0, 1.0, 0.0);
	 glVertex3f(x3, y3, z3);
	 glVertex3f(x3*norm, y3*norm, z3*norm);
   glEnd();
   
   glBegin(GL_LINES);
	 glColor3f(1.0, 1.0, 1.0);
	 glVertex3f(x4, y4, z4);
	 glVertex3f(x4*norm, y4*norm, z4*norm);
   glEnd();
   
  }
 
//Исключительно Для тестов других методов нормалей - клавиша M включает 
 if(qnormal) {
   //Рисуем полигон
   glBegin(GL_QUADS);
   
    glColor3f(1.0, 0.0, 0.0);
    glNormal3f((x1+x2+x3+x4)/4, (y1+y2+y3+y4)/4, (z1+z2+z3+z4)/4);
    glVertex3f(x1, y1, z1);
        
    //glColor3f(0.0, 0.0, 1.0);
    glVertex3f(x2, y2, z2);
        
    glColor3f(1.0, 1.0, 0.0);
    glVertex3f(x3, y3, z3);
        
    //glColor3f(0.0, 1.0, 0.0);
    glVertex3f(x4, y4, z4);
   glEnd();
   
   
  //Рисуем по 1 нормали
   glBegin(GL_LINES);
	 glColor3f(1.0, 1.0, 1.0);
	 glVertex3f((x1+x2+x3+x4)/4, (y1+y2+y3+y4)/4, (z1+z2+z3+z4)/4);
	 glVertex3f((x1+x2+x3+x4)/4 * norm, (y1+y2+y3+y4)/4 * norm, (z1+z2+z3+z4)/4 * norm);
   glEnd();
  }
    
}

void Sphere(float radius, float verTicks, float horTicks){
	
  float Dvert = M_PI/verTicks;
  float DHoriz = 2*M_PI/(horTicks) / hgap;
  float fi, theta, x1,y1,z1,x2,y2,z2,x3,y3,z3,x4,y4,z4;
  
  for (fi = 0; fi <= 2*M_PI; fi += DHoriz){
    for (theta = 0; theta <= M_PI; theta += Dvert) {
		
      x1 = radius*sin(theta)*cos(fi);
      y1 = radius*sin(theta)*sin(fi);
      z1 = radius*cos(theta);

      x2 = radius*sin(theta+DHoriz)*cos(fi);
      y2 = radius*sin(theta+DHoriz)*sin(fi);
      z2 = radius*cos(theta+DHoriz);

      x3 = radius*sin(theta+DHoriz)*cos(fi+Dvert);
      y3 = radius*sin(theta+DHoriz)*sin(fi+Dvert);
      z3 = radius*cos(theta+DHoriz);

      x4 = radius*sin(theta)*cos(fi+Dvert);
      y4 = radius*sin(theta)*sin(fi+Dvert);
      z4 = radius*cos(theta);
      
      DrawQuad(x1,x2,x3,x4,y1,y2,y3,y4,z1,z2,z3,z4);
    }
  }
}


void AspectView() {
  glTranslatef(0, 0, zPos);
  glRotatef(RotX, 1.0, 0.0, 0.0);
  glRotatef(RotY, 0.0, 1.0, 0.0);
  glScalef(Sx, Sy, Sz);
  
}



void Reshape(GLint w, GLint h) {
  glViewport(0, 0, w, h);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  float Aspect = Width/Height;
  gluPerspective(Visio, Aspect, 1.0f, 1000.0f);
}

void initScene(void) {

  

  //Установка Фонового освещения
  float ambient[4] = {0.5, 0.5, 0.5, 1.0};
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient);
  
  glEnable(GL_LIGHTING);
  glEnable(GL_COLOR_MATERIAL);
  glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
  glEnable(GL_DEPTH_TEST);
  
  //glColor3f(0.3, 0.8, 0.4);
  //Загрузка Текстуры
  glEnable(GL_TEXTURE_2D);
  GLuint texture;
  texture = LoadTexture("globus.bmp");
  glBindTexture (GL_TEXTURE_2D, texture);
  
  
  
  glMatrixMode(GL_PROJECTION);
  
  float Aspect = Width/Height;
  gluPerspective(Visio, Aspect, 1.0f, 1000.0f);
  glMatrixMode(GL_MODELVIEW);

 
}

void display(void) {
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);
  glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
  glLoadIdentity();
  
  
  
  // Освещение
  float light0_diffuse[] = {0.5, 0.5, 0.5, 1.0};  
  float light0_direction[] = {30, 80, 30.0, 1.0}; 
  glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
  glLightfv(GL_LIGHT0, GL_POSITION, light0_direction);
  
  if(light ==1) {
	glEnable(GL_LIGHT0);  
  }
  else {
	glDisable(GL_LIGHT0);   
  }
  
  AspectView();
  Sphere(10.0, 40, 40);
  glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y){
	
 if (key == 'f') {
	 if(gradient == 1) {
		 gradient--;
	  }
	  
	 else {
     gradient++;
	  }
	 
     glutPostRedisplay();
 }	

 if (key == 't') {
	 if(texture == 1) {
		 texture--;
	  }
	  
	 else {
     texture++;
	  }
	 
     glutPostRedisplay();
 }	
 
 if (key == 'n') {
	 if(normal == 1) {
		 normal--;
	  }
	  
	 else {
     normal++;
	  }
	 
     glutPostRedisplay();
 }
 
 if (key == 'm') {
	 if(qnormal == 1) {
		 qnormal--;
	  }
	  
	 else {
     qnormal++;
	  }
	 
     glutPostRedisplay();
 }		
	
 if (key == 'l') {
	 if(light == 1) {
		 light--;
	  }
	  
	 else {
     light++;
	  }
	 
     glutPostRedisplay();
 }		
  
  
 if (key == 'w') {
    RotX += RotDiff;
    glutPostRedisplay();
    
 }	
 
 if (key == 's') {
    RotX -= RotDiff;
    glutPostRedisplay();
    
 }
 
 if (key == 'a') {
    RotY += RotDiff;
    glutPostRedisplay();
    
 }
 
 if (key == 'd') {
    RotY -= RotDiff;
    glutPostRedisplay();
    
 }
	
}

void keyboardArrows(int key, int x, int y){
  switch(key) {
	case GLUT_KEY_UP:
    Sx*= Scal;
    Sy*=Scal;
    Sz*=Scal;
    glutPostRedisplay();
    break;  
	  
    case GLUT_KEY_DOWN:
    Sx/= Scal;
    Sy/=Scal;
    Sz/=Scal;
    glutPostRedisplay();  
    break;
      
    case GLUT_KEY_LEFT:
      
    break;
      
    case GLUT_KEY_RIGHT:
      
    break;
    
  }
}



int main(int argc, char **argv) {
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(Width, Height);
  glutInitWindowPosition(0, 0);
  glutCreateWindow("LABA_5");
  glutDisplayFunc(display);
  glutReshapeFunc(Reshape);  
  glutKeyboardFunc(keyboard);
  glutSpecialFunc(keyboardArrows);
  initScene();
  glutMainLoop();
  return 0;             
}
